//
//  ViewController.m
//  UjetObjec
//
//  Created by Hrishi Amravatkar on 8/9/18.
//  Copyright © 2018 Hrishi Amravatkar. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (nonatomic, strong) NSMutableDictionary *lookupDict;
@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.lookupDict = [[NSMutableDictionary alloc] init];
    NSString *inputString = @"Abcda";

    [self printFirstNonRepeatedChar:inputString];
}

- (void) printFirstNonRepeatedChar:(NSString *)inputString {
    //sanity checks
    NSMutableArray *sequentialArrayLookup = [[NSMutableArray alloc] init];
    
    NSString *currentString = [inputString lowercaseString];
    for (int i = 0; i < [currentString length]; i ++) {
        char currentChar = [currentString characterAtIndex:i];
        NSString *currentStringKey = [NSString stringWithFormat:@"%c", currentChar];
        
        if([self.lookupDict objectForKey:currentStringKey]) {
            int currentCount = [[self.lookupDict objectForKey:currentStringKey] intValue];
            currentCount ++;
            [self.lookupDict setObject:@(currentCount) forKey:currentStringKey];
        } else {
            [self.lookupDict setObject:@(1) forKey:currentStringKey];
            [sequentialArrayLookup addObject:currentStringKey];
        }
    }
    
    //Print the first char with 1 occurance
     for (int i = 0; i < [sequentialArrayLookup count]; i ++) {
         NSString *currentStringKey = sequentialArrayLookup[i];
         if([[self.lookupDict objectForKey:currentStringKey] intValue] == 1) {
             NSLog(@"%@", currentStringKey);
             break;
         }
     }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
