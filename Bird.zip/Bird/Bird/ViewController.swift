//
//  ViewController.swift
//  Bird
//
//  Created by Hrishi Amravatkar on 6/29/18.
//  Copyright © 2018 Hrishi Amravatkar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var answer1: UILabel!
    @IBOutlet weak var answer2: UILabel!
    @IBOutlet weak var answer3: UILabel!
    @IBOutlet weak var answer4: UILabel!
    @IBOutlet weak var answer5: UILabel!
    @IBOutlet weak var answer6: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Parse Data
        Utils.parseData(filePath: "events")
        answer1.text = "Total Birds Dropped are:  \(Utils.birdIdDict.count)"
        
        var furthestBirdId :String!
        var furthestDistance:Double = 0.0
        for(birdId, events) in Utils.birdIdDict {
            let currentBirdIdDistance = Utils.calculateDistance(withX1: events[0].eventX, withY1: events[0].eventY, withX2: events[events.count - 1].eventX, withY2: events[events.count - 1].eventY)
            print("distance \(currentBirdIdDistance)")
            if currentBirdIdDistance > furthestDistance {
                furthestDistance = currentBirdIdDistance
                furthestBirdId = birdId
            }
        }
        answer2.text = "Furthest distance is \(furthestDistance) by BirdId \(String(furthestBirdId))"
        
        var maxTotalDistanceBirdId :String!
        var maxTotalDistance:Double = 0.0
        for(birdId, events) in Utils.birdIdDict {
            let currentTotalDistance = Utils.calculateTotalDistance(events: events)
            if currentTotalDistance > maxTotalDistance {
                maxTotalDistance = currentTotalDistance
                maxTotalDistanceBirdId = birdId
            }
        }
        answer3.text = "BirdId with longest distance in total on all of its rides is \(String(maxTotalDistanceBirdId)) with distance of \(maxTotalDistance)"
        
        var maxTotalBillUserId :String!
        var maxTotalBill:Double = 0
        for(userId, _) in Utils.userIdDict {
            let currentTotalBill = Utils.calculateTotalBillPerUser(userId: userId)
            if currentTotalBill > maxTotalBill {
                maxTotalBill = currentTotalBill
                maxTotalBillUserId = userId
            }
        }
        answer4.text = "UserId who paid most is \(String(maxTotalBillUserId)) woth total bill of $\(maxTotalBill + 1)"
        
        var maxWaitTimeBirdId :String!
        var maxWaitTime:Double = 0
        for(birdId, _) in Utils.birdIdDict {
            let currentBirdMaxWaitTime = Utils.calculateLongestWaitPerBird(birdId: birdId)
            if currentBirdMaxWaitTime > maxWaitTime {
                maxWaitTime = currentBirdMaxWaitTime
                maxWaitTimeBirdId = birdId
            }
        }
        answer5.text = "Bird has the longest wait time between two rides is \(String(maxWaitTimeBirdId)) with \(maxWaitTime) secs"
        
        answer6.text = "Average speed across all rides is \(String(Utils.averageSpeedAcrossAllRides())) per sec."
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

