//
//  EventType.swift
//  Bird
//
//  Created by Hrishi Amravatkar on 6/29/18.
//  Copyright © 2018 Hrishi Amravatkar. All rights reserved.
//

import Foundation

public enum EventType: String {
    case DROP = "DROP"
    case START_RIDE = "START_RIDE"
    case END_RIDE = "END_RIDE"
    
}
