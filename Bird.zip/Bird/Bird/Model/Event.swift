//
//  Event.swift
//  Bird
//
//  Created by Hrishi Amravatkar on 6/29/18.
//  Copyright © 2018 Hrishi Amravatkar. All rights reserved.
//

import Foundation

class Event {
    var timestamp: Double!
    var birdId: String!
    var eventType: EventType!
    var eventX: Double!
    var eventY: Double!
    var userId: String?
    
    init(timestamp: Double, birdId: String, eventType: EventType, eventX: Double, eventY: Double, userId: String) {
        self.timestamp = timestamp
        self.birdId = birdId
        self.eventType = eventType
        self.eventX = eventX
        self.eventY = eventY
        self.userId = userId
    }
    
}
