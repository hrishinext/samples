//
//  Utils.swift
//  Bird
//
//  Created by Hrishi Amravatkar on 6/29/18.
//  Copyright © 2018 Hrishi Amravatkar. All rights reserved.
//

import Foundation

class Utils {
    
    static var birdIdDict :[String: [Event]] = [:]
    static var userIdDict :[String: [Event]] = [:]
    
    static func parseData(filePath : String) {
        //var eventDict : [String : [Event]] = [:]
        if let path = Bundle.main.path(forResource: filePath, ofType: "txt") {
            do {
            let data = try String(contentsOfFile: path, encoding: .utf8)
                let outputStrings = data.components(separatedBy: .newlines)
                for eventValue:String in outputStrings {
                    if !eventValue.isEmpty {
                        //split by comma
                        var eventDataArr = eventValue.components(separatedBy: ",")
                        //generate a Event object
                        let event = Event(timestamp: Double(eventDataArr[0])!, birdId:  eventDataArr[1], eventType: EventType(rawValue: eventDataArr[2])!, eventX: Double(Float(eventDataArr[3])!), eventY: Double(Float(eventDataArr[4])!), userId: eventDataArr[5])
                        //generate the birdId eventDict
                        //eventDict is a dictionary of birdId as key and List of events related to birdId as value
                        if var eventList = birdIdDict[event.birdId] {
                            eventList.append(event)
                            birdIdDict[event.birdId] = eventList
                        } else {
                            let eventList:[Event] = [event]
                            birdIdDict[event.birdId] = eventList
                        }
                        
                        //generate the userId eventDict
                        //eventDict is a dictionary of userId as key and List of events related to userId as value
                        if let userId = event.userId {
                            if var eventList = userIdDict[userId] {
                                eventList.append(event)
                                userIdDict[userId] = eventList
                            } else {
                                let eventList:[Event] = [event]
                                userIdDict[userId] = eventList
                            }
                        }
                    }
                }
            } catch {
                print(error)
            }
        }
    }
    
    static func calculateTotalDistance(events: [Event]) -> Double {
        //bird travelled furthest total rides.
        var totalDistance: Double = 0
        var startEvent: Event!
        for event: Event in events {
            if event.eventType == EventType.START_RIDE {
                startEvent = event
            }
            if event.eventType == EventType.END_RIDE {
                totalDistance += Utils.calculateDistance(withX1: startEvent.eventX, withY1: startEvent.eventY, withX2: event.eventX, withY2: event.eventY)
            }
        }
        return totalDistance
    }
    
    static func calculateTotalBillPerUser(userId: String!) -> Double {
        var totalBill: Double = 0
        var startEvent: Event!
        
        for event: Event in Utils.userIdDict[userId]! {
            if event.eventType == EventType.START_RIDE {
                startEvent = event
            }
            if event.eventType == EventType.END_RIDE {
                let currentSecDiff = Utils.calculateTimeDifference(withTimestamp1: startEvent.timestamp, withTimestamp2: event.timestamp)
                let roundedMins = (currentSecDiff / 60).rounded(.up)
                totalBill += (roundedMins * 0.15)
            }
        }
        return totalBill
    }
    
    static func calculateLongestWaitPerBird(birdId: String!) -> Double {
        var maxWait: Double = 0
        var endEvent: Event!
        
        for event: Event in Utils.birdIdDict[birdId]! {
            if event.eventType == EventType.START_RIDE {
                if endEvent != nil {
                    //calculate the wait
                    let currentWait = event.timestamp - endEvent.timestamp
                    if currentWait > maxWait {
                        maxWait = currentWait
                    }
                }
            }
            if event.eventType == EventType.END_RIDE {
                endEvent = event
            }
        }
        return maxWait
    }
    
    static func averageSpeedAcrossAllRides() -> Double {
        var totalRideCount: Double = 0
        var totalSpeed: Double = 0
        for (_, events) in Utils.birdIdDict {
            var startEvent: Event!
            for event: Event in events {
                if event.eventType == EventType.START_RIDE {
                    startEvent = event
                }
                if event.eventType == EventType.END_RIDE {
                    let currentDistance = (Utils.calculateDistance(withX1: startEvent.eventX, withY1: startEvent.eventY, withX2: event.eventX, withY2: event.eventY))
                    let currentTime =  event.timestamp - startEvent.timestamp
                    totalSpeed += (currentDistance/currentTime)
                    totalRideCount += 1
                }
            }
        }
        return (totalSpeed/totalRideCount)
    }
    
    static func calculateDistance(withX1 x1: Double, withY1 y1: Double, withX2 x2: Double, withY2 y2: Double) -> Double {
        let distance = sqrt(pow((x2 - x1), 2) + pow((y2 - y1), 2))
        return distance
    }
    
    private static func calculateTimeDifference(withTimestamp1 timestamp1: Double, withTimestamp2 timestamp2: Double) -> Double {
        let timeDiff = timestamp2 - timestamp1
        if timeDiff < 60 {
            return 0
        }
        return timeDiff
    }
}
