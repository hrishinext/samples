//
//  DataManagerTeests.swift
//  EventsTests
//
//  Created by Hrishikesh Amravatkar on 9/17/19.
//  Copyright © 2019 Hrishikesh Amravatkar. All rights reserved.
//

import XCTest


class EventDataManagerTests: XCTestCase {

    func testLoadEvents() {
        let expectations: XCTestExpectation = self.expectation(description: "eventDataTest")
        EventDataManager.loadEvents("mock_test", { (events) in
            XCTAssertTrue(events.count == 2)
            expectations.fulfill()
        }) { (error) in
            print(error)
        }
        waitForExpectations(timeout: 3,handler: nil)
    }

    func testLoadEventsInvalidJson() {
        let expectations: XCTestExpectation = self.expectation(description: "eventDataTest")
        EventDataManager.loadEvents("mock_test_invalid", { (events) in
        }) { (error) in
            expectations.fulfill()
        }
        waitForExpectations(timeout: 3,handler: nil)
    }
    
    func testLoadEventsNotFile() {
        let expectations: XCTestExpectation = self.expectation(description: "eventDataTest")
        EventDataManager.loadEvents("mock_ABC", { (events) in
        }) { (error) in
            expectations.fulfill()
        }
        waitForExpectations(timeout: 3,handler: nil)
    }

}
