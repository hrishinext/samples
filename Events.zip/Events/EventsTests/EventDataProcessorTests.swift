//
//  EventDataProcessorTests.swift
//  EventsTests
//
//  Created by Hrishikesh Amravatkar on 9/17/19.
//  Copyright © 2019 Hrishikesh Amravatkar. All rights reserved.
//

import XCTest

class EventDataProcessorTests: XCTestCase {

    func testEventsOrder() {
        let expectations: XCTestExpectation = self.expectation(description: "eventDataTest")
        EventDataManager.loadEvents("mock_test", { (events) in
            let eventsReturned = EventDataProcessor.orderEvents(events)
            XCTAssertEqual(eventsReturned[0].eventTitle, "Evening Picnic")
            XCTAssertEqual(eventsReturned[1].eventTitle, "Nap Break")
            expectations.fulfill()
        }) { (error) in
            print(error)
        }
        waitForExpectations(timeout: 3,handler: nil)
    }
    
    func testEventsOrderEmptyArray() {
        let expectations: XCTestExpectation = self.expectation(description: "eventDataTest")
        EventDataManager.loadEvents("mock_test_empty", { (events) in
            let eventsReturned = EventDataProcessor.orderEvents(events)
            XCTAssertEqual(eventsReturned.count, 0)
            expectations.fulfill()
        }) { (error) in
            print(error)
        }
        waitForExpectations(timeout: 3,handler: nil)
    }
    
    func testEventsOrderedConflicts() {
        let expectations: XCTestExpectation = self.expectation(description: "eventDataTest")
        EventDataManager.loadEvents("mock_test_conflicts", { (events) in
            var eventsReturned = EventDataProcessor.orderEvents(events)
            XCTAssertTrue(eventsReturned.count == 2)
            EventDataProcessor.updateConflicts(&eventsReturned)
            XCTAssertTrue(eventsReturned[0].isConflict == true)
            XCTAssertTrue(eventsReturned[1].isConflict == true)
            expectations.fulfill()
        }) { (error) in
            print(error)
        }
        waitForExpectations(timeout: 3,handler: nil)
    }
    
    func testEventsOrderedNoConflicts() {
        let expectations: XCTestExpectation = self.expectation(description: "eventDataTest")
        EventDataManager.loadEvents("mock_test_no_conflicts", { (events) in
            var eventsReturned = EventDataProcessor.orderEvents(events)
            XCTAssertTrue(eventsReturned.count == 2)
            EventDataProcessor.updateConflicts(&eventsReturned)
            XCTAssertTrue(eventsReturned[0].isConflict == false)
            XCTAssertTrue(eventsReturned[1].isConflict == false)
            expectations.fulfill()
        }) { (error) in
            print(error)
        }
        waitForExpectations(timeout: 3,handler: nil)
    }

}
