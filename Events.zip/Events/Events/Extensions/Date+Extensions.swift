//
//  Date+Extensions.swift
//  Events
//
//  Created by Hrishikesh Amravatkar on 9/17/19.
//  Copyright © 2019 Hrishikesh Amravatkar. All rights reserved.
//

import Foundation

extension Date {
    func formatToString() -> String {
        let dateFormatterGet = DateFormatter()
        dateFormatterGet.dateFormat = "yyyy-MM-dd hh:mm a"
        dateFormatterGet.timeZone = TimeZone(abbreviation: "GMT")
        return dateFormatterGet.string(from: self)
    }
}
