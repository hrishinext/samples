//
//  EventModel.swift
//  Events
//
//  Created by Hrishikesh Amravatkar on 9/15/19.
//  Copyright © 2019 Hrishikesh Amravatkar. All rights reserved.
//
import Foundation

struct EventModel {
    var eventTitle: String
    var eventStart: Date
    var eventEnd: Date
    var isConflict: Bool
    
    init(eventTitle: String, eventStart: Date, eventEnd: Date) {
        self.eventTitle = eventTitle
        self.eventStart = eventStart
        self.eventEnd = eventEnd
        self.isConflict = false
    }
}
