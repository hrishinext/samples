//
//  EventTableViewCell.swift
//  Events
//
//  Created by Hrishikesh Amravatkar on 9/15/19.
//  Copyright © 2019 Hrishikesh Amravatkar. All rights reserved.
//

import UIKit

class EventTableViewCell: UITableViewCell {

    @IBOutlet var eventLabel: UILabel!
    @IBOutlet var eventStartTime: UILabel!
    @IBOutlet var eventEndTime: UILabel!
    @IBOutlet var conflict: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
