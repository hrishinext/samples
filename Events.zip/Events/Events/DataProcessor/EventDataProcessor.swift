//
//  DataProcessor.swift
//  Events
//
//  Created by Hrishikesh Amravatkar on 9/17/19.
//  Copyright © 2019 Hrishikesh Amravatkar. All rights reserved.
//

import UIKit

class EventDataProcessor {
    
    //MergeSort the intervals based on start Date
    // Runtime time complexity of O(nlogn)
    static func orderEvents(_ events: [EventModel]) -> [EventModel] {
        
        if events.count == 0 {
            return []
        }
        if events.count < 2 {
            return events
        }
        let mid = events.count / 2
        let leftArray = Array(events[0 ..< mid])
        let rightArray = Array(events[mid ..< events.count])
        
        return merge(orderEvents(leftArray), orderEvents(rightArray))
    }
    
    //compare start dates only
    private static func merge(_ arrayLeft: [EventModel], _ arrayRight: [EventModel]) -> [EventModel] {
        var resultArray = [EventModel]()
        var i = 0
        var j = 0
        
        while i < arrayLeft.count && j < arrayRight.count {
            if arrayLeft[i].eventStart < arrayRight[j].eventStart {
                resultArray.append(arrayLeft[i])
                i += 1
            } else {
                resultArray.append(arrayRight[j])
                j += 1
            }
        }
        
        while i < arrayLeft.count {
            resultArray.append(arrayLeft[i])
            i += 1
        }
        
        while j < arrayRight.count {
            resultArray.append(arrayRight[j])
            j += 1
        }
        
        return resultArray
    }
    
    //Report Conflicts from Events
    //Runtime complexity of O(n)
    static func updateConflicts(_ events: inout [EventModel]) {
        for i in 0 ..< events.count - 1  {
            //endTime of current Event is greater than startTime of the next event
            if events[i].eventEnd > events[i+1].eventStart {
                events[i].isConflict = true
                events[i+1].isConflict = true
            }
        }
    }

}
