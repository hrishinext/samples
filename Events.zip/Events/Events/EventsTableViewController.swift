//
//  EventsTableViewController.swift
//  Events
//
//  Created by Hrishikesh Amravatkar on 9/15/19.
//  Copyright © 2019 Hrishikesh Amravatkar. All rights reserved.
//

import UIKit

class EventsTableViewController: UITableViewController {

    var events:[EventModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
         //Total Runtime complexity of O(nLogn) + O(n)
         //Big O notation of O(nlogn)
         EventDataManager.loadEvents(Constants.dataFile, { (events) in
            //merge sort the events list
            self.events = EventDataProcessor.orderEvents(events)
            //update conflicts
            EventDataProcessor.updateConflicts(&self.events)
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }, { (error) in
            let alertViewController: UIAlertController = UIAlertController(title: "Error", message: "Sorry! Something went wrong!", preferredStyle: .alert)
            self.present(alertViewController, animated: false, completion: nil)
        })
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return events.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "EventTableViewCell", for: indexPath) as! EventTableViewCell

        // Configure the cell...
        let event:EventModel =  self.events[indexPath.row]
        cell.eventLabel.text = event.eventTitle
        cell.eventStartTime.text = event.eventStart.formatToString()
        cell.eventEndTime.text = event.eventEnd.formatToString()
        if event.isConflict {
            cell.conflict.text = "Conflict"
        } else {
            cell.conflict.text = ""
        }
        return cell
    }
    
    override  func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150.0
    }

}
