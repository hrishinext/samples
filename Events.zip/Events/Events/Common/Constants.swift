//
//  Constants.swift
//  Events
//
//  Created by Hrishikesh Amravatkar on 9/16/19.
//  Copyright © 2019 Hrishikesh Amravatkar. All rights reserved.
//

import UIKit

struct Constants {
    static let dataFile: String = "mock"
}
