//
//  DataManager.swift
//  Events
//
//  Created by Hrishikesh Amravatkar on 9/15/19.
//  Copyright © 2019 Hrishikesh Amravatkar. All rights reserved.
//

import Foundation

struct EventDataManager {
    
    private init() {
    }
    
    static func loadEvents(_ jsonFile: String,
                           _ success: @escaping(([EventModel]) -> Void),
                           _ failure: @escaping(Error) -> Void) {
        do {
            if let path = Bundle.main.path(forResource: jsonFile, ofType: "json") {
                var events:[EventModel] = []
                let jsonData = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                if let jsonArray = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [AnyObject] {
                    for value in jsonArray {
                        if let dictValue = value as? [String:String] {
                            let dateFormatter = DateFormatter()
                            dateFormatter.dateFormat = "MMMM dd, yyyy hh:mm a" //If you dont want static
                            dateFormatter.timeZone = TimeZone(abbreviation: "GMT")
                            let startDate: Date = dateFormatter.date(from: dictValue["start"]!)!
                            let endDate: Date = dateFormatter.date(from: dictValue["end"]!)!
                            let event: EventModel = EventModel(eventTitle: dictValue["title"] ?? "", eventStart: startDate, eventEnd: endDate)
                            events.append(event)
                        }
                    }
                }
                success(events)
            } else {
                 failure(NSError(domain: "Filenotfound", code: 404, userInfo: nil))
            }
        } catch {
            failure(error)
        }
    }
}
