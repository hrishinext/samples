//
//  Photo.swift
//  Leanplum
//
//  Created by Hrishi Amravatkar on 7/30/18.
//  Copyright © 2018 Hrishi Amravatkar. All rights reserved.
//

import Foundation

public class Photo {
    
    let imageId: String
    let imageUrl: String
    
    init(imageId: String, imageUrl: String) {
        self.imageId = imageId
        self.imageUrl = imageUrl
    }
    
}
