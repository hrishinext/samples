//
//  ImagesApi.swift
//  Leanplum
//
//  Created by Hrishi Amravatkar on 7/30/18.
//  Copyright © 2018 Hrishi Amravatkar. All rights reserved.
//

import Foundation

public class ImagesApi {
    
    func searchImages(searchText: String, success: @escaping(_ success: [Photo]) -> Void, failure: @escaping(_ failure: Error) -> Void) {
        
        var urlString = "https://api.imgur.com/3/gallery/search/?"
        let parametersDictionary = ["q" : searchText]
        for (key, value) in parametersDictionary {
            urlString.append("\(key)=\(value)")
        }
        
        guard let serviceUrl = URL(string: urlString) else {return}
        var request = URLRequest(url: serviceUrl)
        request.httpMethod = "GET"
        request.setValue("Client-ID b7d5e29a3f875d3", forHTTPHeaderField: "Authorization")
        request.setValue("Application/json", forHTTPHeaderField: "Content-Type")
        
        let session = URLSession.shared
        session.dataTask(with: request) { (data, response, error) in
            if let data = data {
                do {
                    let jsonData = try JSONSerialization.jsonObject(with: data, options: [])
                    var resultPhotos:Array<Photo> = [Photo]()
                    if let jsonDict = jsonData as? Dictionary<String, AnyObject> {
                        let photos = jsonDict["data"] as! Array<AnyObject>
                        for photoData in photos {
                            let photoCurrentData = photoData as! Dictionary<String, AnyObject>
                            let photo = Photo(imageId: photoCurrentData["id"] as! String, imageUrl: photoCurrentData["link"] as! String)
                            resultPhotos.append(photo)
                        }
                    }
                    success(resultPhotos)
                } catch {
                    failure(error)
                }
            }
        }.resume()
        
    }
}
