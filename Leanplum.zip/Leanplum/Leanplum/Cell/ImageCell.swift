//
//  ImageCell.swift
//  Leanplum
//
//  Created by Hrishi Amravatkar on 7/30/18.
//  Copyright © 2018 Hrishi Amravatkar. All rights reserved.
//

import UIKit

public class ImageCell: UITableViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    
}
