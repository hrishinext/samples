//
//  ViewController.swift
//  Civic
//
//  Created by Hrishi Amravatkar on 7/16/18.
//  Copyright © 2018 Hrishi Amravatkar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    var squareViewContainer: UIView!
    var button0: UIButton!
    var button1: UIButton!
    var button2: UIButton!
    var button3: UIButton!
    var button4: UIButton!
    var button5: UIButton!
    var button6: UIButton!
    var button7: UIButton!
    var button8: UIButton!
    var button9: UIButton!
    
    
    override var shouldAutorotate: Bool {
        return false
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .portrait
    }
    
    override var preferredInterfaceOrientationForPresentation: UIInterfaceOrientation {
        return .portrait
    }
    
    override func loadView() {
        super.loadView()
        
        
        let test: String = "Hrishikesh"
        
        print(test.)
        
        self.squareViewContainer = UIView()
        self.button0 = UIButton()
        self.button0.backgroundColor = UIColor.black
        self.button1 = UIButton()
        self.button1.backgroundColor = UIColor.blue
        self.button2 = UIButton()
        self.button2.backgroundColor = UIColor.red
        self.button3 = UIButton()
        self.button3.backgroundColor = UIColor.black
        self.button4 = UIButton()
        self.button4.backgroundColor = UIColor.black
        self.button5 = UIButton()
        self.button5.backgroundColor = UIColor.black
        self.button6 = UIButton()
        self.button6.backgroundColor = UIColor.black
        self.button7 = UIButton()
        self.button7.backgroundColor = UIColor.black
        self.button8 = UIButton()
        self.button8.backgroundColor = UIColor.black
        self.button9 = UIButton()
        self.button9.backgroundColor = UIColor.black
        
        squareViewContainer.translatesAutoresizingMaskIntoConstraints = false
        
        button0.translatesAutoresizingMaskIntoConstraints = false
        button1.translatesAutoresizingMaskIntoConstraints = false
        button2.translatesAutoresizingMaskIntoConstraints = false
        button3.translatesAutoresizingMaskIntoConstraints = false
        button4.translatesAutoresizingMaskIntoConstraints = false
        button5.translatesAutoresizingMaskIntoConstraints = false
        button6.translatesAutoresizingMaskIntoConstraints = false
        button7.translatesAutoresizingMaskIntoConstraints = false
        button8.translatesAutoresizingMaskIntoConstraints = false
        button9.translatesAutoresizingMaskIntoConstraints = false
        
        self.view.addSubview(squareViewContainer)
        NSLayoutConstraint.activate([
            squareViewContainer.widthAnchor.constraint(equalToConstant: 300),
            squareViewContainer.heightAnchor.constraint(equalToConstant: 300),
            squareViewContainer.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
            squareViewContainer.centerYAnchor.constraint(equalTo: self.view.centerYAnchor),
            ])
        
    
        self.squareViewContainer.addSubview(self.button0)
        self.squareViewContainer.addSubview(self.button1)
        self.squareViewContainer.addSubview(self.button2)
        
        let views: [String: Any] = [
            "button0": button0,
            "button1": button1,
            "button2": button2,
            "button3": button3,
            "button4": button4,
            "button5": button5,
            "button6": button6,
            "button7": button7,
            "button8": button8,
            "button9": button9]
        
        var allButtonConstraints: [NSLayoutConstraint] = []
        
        let b0VerticalConstraints = NSLayoutConstraint.constraints(
            withVisualFormat: "V:|-20-[button0(50)]",
            metrics: nil,
            views: views)
        
        allButtonConstraints += b0VerticalConstraints
        
        /*let b0HorizontalConstraints = NSLayoutConstraint.constraints(
            withVisualFormat: "H:|-20-[button0(50)]-20-[button1(50)]-20-[button2(50)]",
            metrics: nil,
            views: views)*/
        //let b0HorizontalConstraints = NSLayoutConstraint.constraints(withVisualFormat: "H:|-20-[button0(50)]-20-[button1(50)]-20-[button2(50)]", metrics: nil, views: views)
        
        let b0HorizontalConstraints = NSLayoutConstraint.constraints(withVisualFormat: "|-(>=20)-[button0(50)]-20-[button1(50)]-20-[button2(50)]-(<=20)-|", options: .alignAllCenterX ,metrics: nil, views: views)
        allButtonConstraints += b0HorizontalConstraints
        
        let b1VerticalConstraints = NSLayoutConstraint.constraints(
            withVisualFormat: "V:|-20-[button1(50)]",
            metrics: nil,
            views: views)
        allButtonConstraints += b1VerticalConstraints
        
        let b2VerticalConstraints = NSLayoutConstraint.constraints(
            withVisualFormat: "V:|-20-[button2(50)]",
            metrics: nil,
            views: views)
        allButtonConstraints += b2VerticalConstraints
        
        NSLayoutConstraint.activate(allButtonConstraints)
    
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Programmatic layout
        
        self.squareViewContainer.backgroundColor = .yellow
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

